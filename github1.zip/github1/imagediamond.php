<pre style=" padding-left:250px;">
<?php

	$n1=$_POST['num1'];
		for($i=1;$i<=$n1;$i++){
			for($j=$n1;$j>0;$j--)
			{
					if($j<$i)
						echo "<img src=image/back1.jpg style=width:30px; style=height:30px>";
					else
						echo "<img src=image/rajesh.jpg style=width:30px; style=height:30px>";
			}
			for($k=2;$k<=$n1;$k++)
			{
				if($k<$i)
					echo "<img src=image/back1.jpg style=width:30px; style=height:30px>";
				else
					echo "<img src=image/rajesh.jpg style=width:30px; style=height:30px>";
			}
				echo "</br>";
		}
		
		
		for($i=($n1-1);$i>0;$i--){
			for($j=$n1;$j>0;$j--)
			{
					if($j<$i)
						echo "<img src=image/back1.jpg style=width:30px; style=height:30px>";
					else
						echo "<img src=image/rajesh.jpg style=width:30px; style=height:30px>";
			}
			for($k=2;$k<=$n1;$k++)
			{
				if($k<$i)
					echo "<img src=image/back1.jpg style=width:30px; style=height:30px>";
				else
					echo "<img src=image/rajesh.jpg style=width:30px; style=height:30px>";
			}
				echo "</br>";
		}
			
			
		
		
		
		
?>
</pre>